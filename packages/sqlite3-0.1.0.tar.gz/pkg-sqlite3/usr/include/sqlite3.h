#ifndef LOT_BOOTSTRAP_SQLITE3_H
#define LOT_BOOTSTRAP_SQLITE3_H

#include <stdarg.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef long long sqlite3_int64;
typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;
typedef int (*sqlite3_callback)(void*,int,char**,char**);
typedef void (*sqlite3_destructor_type)(void*);

struct sqlite3 {
    sqlite3_int64 last_rowid;
    int changes;
    int errcode;
    int exterr;
    const char *errmsg;
};

struct sqlite3_stmt {
    sqlite3 *db;
    int state;
};

#define SQLITE_OK 0
#define SQLITE_ERROR 1
#define SQLITE_INTERNAL 2
#define SQLITE_PERM 3
#define SQLITE_ABORT 4
#define SQLITE_BUSY 5
#define SQLITE_PROTOCOL 15
#define SQLITE_ROW 100
#define SQLITE_DONE 101
#define SQLITE_NULL 5

#define SQLITE_OPEN_READONLY 0x00000001
#define SQLITE_OPEN_READWRITE 0x00000002
#define SQLITE_OPEN_CREATE 0x00000004
#define SQLITE_OPEN_URI 0x00000040

#define SQLITE_FCNTL_PERSIST_WAL 10

#define SQLITE_TRANSIENT ((sqlite3_destructor_type)-1)

int sqlite3_open_v2(const char *filename, sqlite3 **ppDb, int flags, const char *zVfs);
int sqlite3_close(sqlite3 *);
int sqlite3_exec(sqlite3*, const char *sql, sqlite3_callback, void *, char **errmsg);
int sqlite3_changes(sqlite3*);
int sqlite3_file_control(sqlite3*, const char *zDbName, int op, void *);
const char *sqlite3_errstr(int);
int sqlite3_errcode(sqlite3*);
int sqlite3_extended_errcode(sqlite3*);
int sqlite3_error_offset(sqlite3*);
const char *sqlite3_db_filename(sqlite3*, const char *zDbName);
const char *sqlite3_errmsg(sqlite3*);
int sqlite3_busy_timeout(sqlite3*, int ms);
void *sqlite3_trace(sqlite3*, void(*xTrace)(void*,const char*), void*);
sqlite3_int64 sqlite3_last_insert_rowid(sqlite3*);

int sqlite3_prepare_v2(sqlite3*, const char *zSql, int nByte, sqlite3_stmt **ppStmt, const char **pzTail);
int sqlite3_finalize(sqlite3_stmt *pStmt);
int sqlite3_reset(sqlite3_stmt *pStmt);
int sqlite3_step(sqlite3_stmt*);

int sqlite3_bind_text(sqlite3_stmt*, int, const char*, int n, sqlite3_destructor_type);
int sqlite3_bind_blob(sqlite3_stmt*, int, const void*, int n, sqlite3_destructor_type);
int sqlite3_bind_int64(sqlite3_stmt*, int, sqlite3_int64);
int sqlite3_bind_null(sqlite3_stmt*, int);

const unsigned char *sqlite3_column_text(sqlite3_stmt*, int iCol);
sqlite3_int64 sqlite3_column_int64(sqlite3_stmt*, int iCol);
int sqlite3_column_type(sqlite3_stmt*, int iCol);
char *sqlite3_expanded_sql(sqlite3_stmt *pStmt);

#ifdef __cplusplus
}
#endif

#endif
