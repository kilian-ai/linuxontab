if(NOT TARGET toml11::toml11)
  add_library(toml11::toml11 INTERFACE IMPORTED)
  get_filename_component(_TOML11_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
  set_target_properties(toml11::toml11 PROPERTIES
    INTERFACE_INCLUDE_DIRECTORIES "${_TOML11_PREFIX}/include"
  )
endif()
set(toml11_FOUND TRUE)
