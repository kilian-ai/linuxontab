#ifndef LOT_BOOTSTRAP_CURL_H
#define LOT_BOOTSTRAP_CURL_H

#include <stddef.h>
#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LIBCURL_VERSION "8.13.0-stub"
#define LIBCURL_VERSION_NUM 0x080d00

typedef long curl_off_t;

typedef struct CURL CURL;
typedef struct CURLM CURLM;

typedef int CURLcode;
typedef int CURLMcode;
typedef int CURLoption;
typedef int CURLINFO;
typedef int CURLMoption;
typedef int curl_infotype;

enum {
    CURLE_OK = 0,
    CURLE_UNSUPPORTED_PROTOCOL = 1,
    CURLE_FAILED_INIT = 2,
    CURLE_URL_MALFORMAT = 3,
    CURLE_NOT_BUILT_IN = 4,
    CURLE_REMOTE_ACCESS_DENIED = 9,
    CURLE_FILE_COULDNT_READ_FILE = 37,
    CURLE_FUNCTION_NOT_FOUND = 41,
    CURLE_ABORTED_BY_CALLBACK = 42,
    CURLE_BAD_FUNCTION_ARGUMENT = 43,
    CURLE_INTERFACE_FAILED = 45,
    CURLE_TOO_MANY_REDIRECTS = 47,
    CURLE_UNKNOWN_OPTION = 48,
    CURLE_SSL_CACERT_BADFILE = 77,
    CURLE_WRITE_ERROR = 23
};

enum {
    CURLM_OK = 0
};

enum {
    CURLMSG_DONE = 1
};

enum {
    CURLINFO_TEXT = 0,
    CURLINFO_PROTOCOL = 0x200000 + 181,
    CURLINFO_RESPONSE_CODE = 0x200000 + 2,
    CURLINFO_EFFECTIVE_URL = 0x100000 + 1
};

enum {
    CURLPROTO_HTTP = 1 << 0,
    CURLPROTO_HTTPS = 1 << 1
};

enum {
    CURLOPT_VERBOSE = 41,
    CURLOPT_DEBUGFUNCTION = 94,
    CURLOPT_URL = 10002,
    CURLOPT_FOLLOWLOCATION = 52,
    CURLOPT_MAXREDIRS = 68,
    CURLOPT_NOSIGNAL = 99,
    CURLOPT_USERAGENT = 10018,
    CURLOPT_PIPEWAIT = 237,
    CURLOPT_HTTP_VERSION = 84,
    CURLOPT_WRITEFUNCTION = 20011,
    CURLOPT_WRITEDATA = 10001,
    CURLOPT_HEADERFUNCTION = 20079,
    CURLOPT_HEADERDATA = 10029,
    CURLOPT_PROGRESSFUNCTION = 20056,
    CURLOPT_PROGRESSDATA = 10057,
    CURLOPT_NOPROGRESS = 43,
    CURLOPT_HTTPHEADER = 10023,
    CURLOPT_MAX_RECV_SPEED_LARGE = 30146,
    CURLOPT_NOBODY = 44,
    CURLOPT_UPLOAD = 46,
    CURLOPT_READFUNCTION = 20012,
    CURLOPT_READDATA = 10009,
    CURLOPT_INFILESIZE_LARGE = 30115,
    CURLOPT_CAINFO = 10065,
    CURLOPT_SSL_VERIFYPEER = 64,
    CURLOPT_SSL_VERIFYHOST = 81,
    CURLOPT_CONNECTTIMEOUT = 78,
    CURLOPT_LOW_SPEED_LIMIT = 19,
    CURLOPT_LOW_SPEED_TIME = 20,
    CURLOPT_NETRC_FILE = 10118,
    CURLOPT_NETRC = 51,
    CURLOPT_RESUME_FROM_LARGE = 30116
};

enum {
    CURLMOPT_PIPELINING = 3,
    CURLMOPT_MAX_TOTAL_CONNECTIONS = 13
};

enum {
    CURLPIPE_MULTIPLEX = 2
};

enum {
    CURL_WAIT_POLLIN = 0x01
};

enum {
    CURL_NETRC_OPTIONAL = 1
};

enum {
    CURL_HTTP_VERSION_1_1 = 2,
    CURL_HTTP_VERSION_2TLS = 4
};

enum {
    CURL_GLOBAL_ALL = 3
};

struct curl_slist {
    char *data;
    struct curl_slist *next;
};

typedef struct {
    int msg;
    CURL *easy_handle;
    union {
        void *whatever;
        CURLcode result;
    } data;
} CURLMsg;

struct curl_waitfd {
    int fd;
    short events;
    short revents;
};

CURL *curl_easy_init(void);
void curl_easy_reset(CURL *curl);
void curl_easy_cleanup(CURL *curl);
CURLcode curl_easy_setopt(CURL *curl, CURLoption option, ...);
CURLcode curl_easy_getinfo(CURL *curl, CURLINFO info, ...);
const char *curl_easy_strerror(CURLcode errornum);

struct curl_slist *curl_slist_append(struct curl_slist *list, const char *string);
void curl_slist_free_all(struct curl_slist *list);

CURLcode curl_global_init(long flags);

CURLM *curl_multi_init(void);
CURLMcode curl_multi_setopt(CURLM *multi_handle, CURLMoption option, ...);
CURLMcode curl_multi_cleanup(CURLM *multi_handle);
CURLMcode curl_multi_perform(CURLM *multi_handle, int *running_handles);
CURLMsg *curl_multi_info_read(CURLM *multi_handle, int *msgs_in_queue);
CURLMcode curl_multi_remove_handle(CURLM *multi_handle, CURL *curl_handle);
CURLMcode curl_multi_add_handle(CURLM *multi_handle, CURL *curl_handle);
CURLMcode curl_multi_wait(CURLM *multi_handle, struct curl_waitfd extra_fds[], unsigned int extra_nfds, int timeout_ms, int *numfds);
const char *curl_multi_strerror(CURLMcode code);

#ifdef __cplusplus
}
#endif

#endif
