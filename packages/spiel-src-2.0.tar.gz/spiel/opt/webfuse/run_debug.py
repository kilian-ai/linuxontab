import sys, os, time
sys.path[:0] = ['/opt/webfuse-libs', '/opt/webfuse']
os.chdir('/opt/webfuse')
def log(*a): print(*a, flush=True)

from app.main import app as real_app
from app.db import init_db
init_db()

# ASGI wrapper: log every response event the app emits, and whether send() returns.
async def app(scope, receive, send):
    if scope.get("type") != "http":
        return await real_app(scope, receive, send)
    log("ASGI recv", scope.get("path"))
    async def logsend(msg):
        t = msg.get("type")
        if t == "http.response.start":
            log("  -> start status", msg.get("status"))
        elif t == "http.response.body":
            log("  -> body", len(msg.get("body", b"")), "more=", msg.get("more_body"))
        await send(msg)
        log("  <- send returned", t)
    try:
        await real_app(scope, receive, logsend)
        log("  app() returned for", scope.get("path"))
    except Exception as e:
        log("  app() RAISED", repr(e))

import uvicorn
uvicorn.run(app, host="127.0.0.1", port=8080, log_level="warning")
