"""Blocking threaded HTTP/1.0 proxy: browser <-> :8080 <-> uvicorn :8081.

Turns each incoming request into a fresh HTTP/1.0 Connection:close request to
uvicorn, so the app never sees keep-alive (which wedges uvicorn's accept loop
on this wasm kernel). Threaded blocking sockets (no asyncio) avoid the wedge.
"""
import socketserver, socket

UPSTREAM = ('127.0.0.1', 8081)

def recv_headers(sock):
    buf = b''
    while b'\r\n\r\n' not in buf:
        d = sock.recv(4096)
        if not d:
            return None, b''
        buf += d
    head, _, rest = buf.partition(b'\r\n\r\n')
    return head, rest

class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        c = self.request
        c.settimeout(60)
        try:
            head, rest = recv_headers(c)
            if head is None:
                return
            lines = head.split(b'\r\n')
            method, path, _ = lines[0].split(b' ', 2)
            headers = lines[1:]
            clen = 0
            for h in headers:
                if h.lower().startswith(b'content-length:'):
                    try: clen = int(h.split(b':', 1)[1])
                    except: clen = 0
            body = rest
            while len(body) < clen:
                d = c.recv(4096)
                if not d: break
                body += d
            up = socket.create_connection(UPSTREAM, timeout=60)
            out = method + b' ' + path + b' HTTP/1.0\r\n'
            for h in headers:
                hl = h.lower()
                if hl.startswith(b'connection:') or hl.startswith(b'host:'):
                    continue
                out += h + b'\r\n'
            out += b'Host: 127.0.0.1\r\nConnection: close\r\n\r\n' + body
            up.sendall(out)
            up.settimeout(60)
            while True:
                d = up.recv(65536)
                if not d: break
                c.sendall(d)          # stream upstream -> client
            up.close()
        except Exception as e:
            try: c.sendall(b'HTTP/1.0 502 Bad Gateway\r\nConnection: close\r\n\r\n' + str(e).encode())
            except: pass
        finally:
            try: c.close()
            except: pass

class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

if __name__ == '__main__':
    print('proxy listening 0.0.0.0:8080 -> uvicorn 127.0.0.1:8081', flush=True)
    Server(('0.0.0.0', 8080), Handler).serve_forever()
