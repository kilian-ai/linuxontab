import socket, sys
def probe(path):
    try:
        s = socket.create_connection(('127.0.0.1', 8080), timeout=10)
    except Exception as e:
        print(path, "CONNECT-FAIL", e); return
    s.sendall(f"GET {path} HTTP/1.0\r\nHost: x\r\n\r\n".encode())
    s.settimeout(15)
    data = b''
    try:
        while True:
            c = s.recv(4096)
            if not c: break
            data += c
    except Exception as e:
        print(path, f"recv-timeout after {len(data)}B", e); return
    line0 = data.split(b'\r\n',1)[0].decode('latin1')
    print(path, "OK", len(data), "bytes:", line0, "|", data[-60:])
for p in ("/ping", "/ping2", "/ping3", "/api/sources"):
    probe(p)
print("PROBE_DONE")
