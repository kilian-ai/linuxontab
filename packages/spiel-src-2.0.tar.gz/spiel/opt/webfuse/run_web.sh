#!/bin/sh
cd /opt/webfuse
export PYTHONPATH=/opt/webfuse-libs:/opt/webfuse
python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8081 --no-access-log > /tmp/uvicorn.log 2>&1 &
sleep 8
exec python3 /opt/webfuse/proxy.py
