#ifndef LOT_BOOTSTRAP_BROTLI_DECODE_H
#define LOT_BOOTSTRAP_BROTLI_DECODE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct BrotliDecoderStateStruct BrotliDecoderState;
typedef int BROTLI_BOOL;

BrotliDecoderState * BrotliDecoderCreateInstance(void *alloc_func, void *free_func, void *opaque);
void BrotliDecoderDestroyInstance(BrotliDecoderState *state);
BROTLI_BOOL BrotliDecoderDecompressStream(BrotliDecoderState *state,
                                          size_t *available_in,
                                          const uint8_t **next_in,
                                          size_t *available_out,
                                          uint8_t **next_out,
                                          size_t *total_out);
BROTLI_BOOL BrotliDecoderIsFinished(const BrotliDecoderState *state);

#ifdef __cplusplus
}
#endif

#endif
