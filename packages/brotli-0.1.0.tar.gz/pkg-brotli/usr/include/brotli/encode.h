#ifndef LOT_BOOTSTRAP_BROTLI_ENCODE_H
#define LOT_BOOTSTRAP_BROTLI_ENCODE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct BrotliEncoderStateStruct BrotliEncoderState;
typedef int BROTLI_BOOL;

typedef enum {
  BROTLI_OPERATION_PROCESS = 0,
  BROTLI_OPERATION_FLUSH = 1,
  BROTLI_OPERATION_FINISH = 2,
  BROTLI_OPERATION_EMIT_METADATA = 3
} BrotliEncoderOperation;

BrotliEncoderState * BrotliEncoderCreateInstance(void *alloc_func, void *free_func, void *opaque);
void BrotliEncoderDestroyInstance(BrotliEncoderState *state);
BROTLI_BOOL BrotliEncoderCompressStream(BrotliEncoderState *state,
                                        BrotliEncoderOperation op,
                                        size_t *available_in,
                                        const uint8_t **next_in,
                                        size_t *available_out,
                                        uint8_t **next_out,
                                        size_t *total_out);
BROTLI_BOOL BrotliEncoderIsFinished(const BrotliEncoderState *state);

#ifdef __cplusplus
}
#endif

#endif
