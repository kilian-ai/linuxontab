#ifndef LOT_BOOTSTRAP_EDITLINE_H
#define LOT_BOOTSTRAP_EDITLINE_H

#ifdef __cplusplus
extern "C" {
#endif

extern const char *rl_readline_name;
extern int el_hist_size;

char *readline(const char *prompt);
int read_history(const char *filename);
int write_history(const char *filename);
void rl_set_complete_func(char *(*func)(char *, int *));
void rl_set_list_possib_func(int (*func)(char *, char ***));

#ifdef __cplusplus
}
#endif

#endif
