#ifndef LOT_BOOTSTRAP_OPENSSL_CRYPTO_H
#define LOT_BOOTSTRAP_OPENSSL_CRYPTO_H

#ifdef __cplusplus
extern "C" {
#endif

int OPENSSL_init_crypto(unsigned long opts, const void * settings);

#ifdef __cplusplus
}
#endif

#endif
