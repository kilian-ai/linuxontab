#ifndef LOT_BOOTSTRAP_OPENSSL_MD5_H
#define LOT_BOOTSTRAP_OPENSSL_MD5_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    unsigned long long h[2];
    unsigned long long n;
} MD5_CTX;

int MD5_Init(MD5_CTX * c);
int MD5_Update(MD5_CTX * c, const void * data, size_t len);
int MD5_Final(unsigned char * md, MD5_CTX * c);

#ifdef __cplusplus
}
#endif

#endif
