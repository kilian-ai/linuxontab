#ifndef LOT_BOOTSTRAP_OPENSSL_SHA_H
#define LOT_BOOTSTRAP_OPENSSL_SHA_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    unsigned long long h[4];
    unsigned long long n;
} SHA_CTX;

typedef struct {
    unsigned long long h[8];
    unsigned long long n;
} SHA256_CTX;

typedef struct {
    unsigned long long h[16];
    unsigned long long n;
} SHA512_CTX;

int SHA1_Init(SHA_CTX * c);
int SHA1_Update(SHA_CTX * c, const void * data, size_t len);
int SHA1_Final(unsigned char * md, SHA_CTX * c);

int SHA256_Init(SHA256_CTX * c);
int SHA256_Update(SHA256_CTX * c, const void * data, size_t len);
int SHA256_Final(unsigned char * md, SHA256_CTX * c);

int SHA512_Init(SHA512_CTX * c);
int SHA512_Update(SHA512_CTX * c, const void * data, size_t len);
int SHA512_Final(unsigned char * md, SHA512_CTX * c);

#ifdef __cplusplus
}
#endif

#endif
