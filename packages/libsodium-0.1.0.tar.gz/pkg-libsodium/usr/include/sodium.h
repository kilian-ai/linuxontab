#ifndef LOT_BOOTSTRAP_SODIUM_H
#define LOT_BOOTSTRAP_SODIUM_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define crypto_sign_BYTES 64
#define crypto_sign_PUBLICKEYBYTES 32
#define crypto_sign_SECRETKEYBYTES 64

int sodium_init(void);
void randombytes_buf(void * const buf, const size_t size);

int crypto_sign_keypair(unsigned char *pk, unsigned char *sk);
int crypto_sign_ed25519_sk_to_pk(unsigned char *pk, const unsigned char *sk);
int crypto_sign_detached(unsigned char *sig,
                         unsigned long long *siglen_p,
                         const unsigned char *m,
                         unsigned long long mlen,
                         const unsigned char *sk);
int crypto_sign_verify_detached(const unsigned char *sig,
                                const unsigned char *m,
                                unsigned long long mlen,
                                const unsigned char *pk);

#ifdef __cplusplus
}
#endif

#endif
