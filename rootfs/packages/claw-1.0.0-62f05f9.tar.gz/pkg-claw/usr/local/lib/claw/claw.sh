#!/bin/sh
# clawlite — minimalist multi-provider LLM REPL
# Pure POSIX sh + curl + jq. No Node, no npm, no TUI lib.
#
# Usage:
#   claw                          REPL, default session
#   claw "prompt here"            one-shot, prints reply, exits
#   echo "hi" | claw              one-shot from stdin
#   claw -s coding                REPL with named session
#   claw -i ~/notes/style.md      extra instruction file (repeatable)
#   claw -m gpt-5.5               model override (this run only)
#   claw -p openai|anthropic      provider override (this run only)
#   claw --journal                inject the per-session journal.md into
#                                 the system prompt (off by default)
#   claw --user-window N          keep last N user prompts in memory
#   claw --assist-window N        keep last N assistant replies in memory
#   claw --md / --no-md           force on/off markdown rendering of reply
#   claw --no-memory              don't persist this turn
#   claw --no-instructions        skip system prompt entirely
#   claw --no-tools               disable shell tool calling
#   claw --confirm                ask y/N before each shell tool call
#   claw --yolo                   run shell tool calls without confirmation (default)
#   claw --mentor                 enable mentor pass (review + revision)
#   claw --no-mentor              disable mentor pass
#   claw --reset                  wipe current session and continue
#   claw --where                  print config + data dirs and exit
#
# Slash commands (REPL):
#   /exit  /quit                  leave
#   /help                         this help
#   /reset                        clear current session history
#   /list                         list saved sessions
#   /load <name>                  switch to session <name>
#   /save <name>                  copy current session to <name>
#   /model <name>                 switch model (this run only)
#   /provider openai|anthropic    switch provider (this run only)
#   /journal on|off|show          toggle/show per-session journal injection
#   /md on|off|auto               toggle markdown rendering of replies
#   /tools on|off                 toggle shell tool calling
#   /yolo on|off                  toggle confirm prompt for shell tools
#   /mentor on|off                toggle mentor pass
#   /inst add <file>              add instruction file (this run only)
#   /inst rm  <file>              remove instruction file (this run only)
#   /inst list                    list active instruction files
#   /inst show                    print combined system prompt
#   /paste                        multi-line input (terminate with EOF)
#
# Files:
#   $XDG_CONFIG_HOME/clawlite/config            env-style settings
#   $XDG_CONFIG_HOME/clawlite/instructions/*.md auto-loaded as system prompt
#                                              (alpha order, includes
#                                               compacted user-rules files)
#   $XDG_DATA_HOME/clawlite/sessions/<name>.user.jsonl       rolling user log
#   $XDG_DATA_HOME/clawlite/sessions/<name>.assistant.jsonl  rolling AI log
#   $XDG_DATA_HOME/clawlite/journals/<name>.journal.md       compacted AI log
#
# Rolling memory model:
#   When the user log exceeds USER_WINDOW (default 20), the oldest entries are
#   compacted by the model into rules-only markdown and appended to
#   $INST_DIR/90-<session>-rules.md (auto-loaded as instructions). The user
#   log is then trimmed back to USER_WINDOW.
#   Same for the assistant log: overflow is compacted into a brief journal
#   entry and appended to $DATA_DIR/journals/<session>.journal.md, which is
#   only injected into the system prompt when --journal / JOURNAL=1.
#
# Required env (or put in config):
#   OPENAI_API_KEY      for provider=openai
#   ANTHROPIC_API_KEY   for provider=anthropic
#
# ----------------------------------------------------------------------

set -u

CFG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/clawlite"
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/clawlite"
SESS_DIR="$DATA_DIR/sessions"
INST_DIR="$CFG_DIR/instructions"
PROMPT_DIR="$CFG_DIR/prompts"
CFG_FILE="$CFG_DIR/config"
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd)
REPO_DEFAULT_CFG="$SCRIPT_DIR/config.default"

mkdir -p "$SESS_DIR" "$INST_DIR" "$PROMPT_DIR"

if [ ! -f "$CFG_FILE" ]; then
  if [ -f "$REPO_DEFAULT_CFG" ]; then
    cp "$REPO_DEFAULT_CFG" "$CFG_FILE"
  else
    cat > "$CFG_FILE" <<'EOF'
# clawlite config — sourced as POSIX shell.
PROVIDER=openai
MODEL_OPENAI=gpt-5.5
MODEL_ANTHROPIC=claude-sonnet-4-5
OPENAI_BASE_URL=https://api.openai.com/v1
ANTHROPIC_BASE_URL=https://api.anthropic.com/v1
# Shell tool calling: model can run commands via <shell>...</shell> blocks.
TOOLS=1
TOOL_MAX_ITERS=50
TOOL_OUTPUT_LIMIT=32768
# Shell tool calls run without confirmation by default. Set CLAW_YOLO=0
# (or pass --confirm) to be prompted before each command.
CLAW_YOLO=1
# Mentor pass: run a second claw instance to critique + revise each answer.
MENTOR=0
# Allow mentor review pass to use shell tools for workspace inspection.
MENTOR_TOOLS=1
# Rolling memory windows (number of entries kept verbatim):
USER_WINDOW=2000
ASSIST_WINDOW=2000
# Set JOURNAL=1 (or pass --journal) to inject the per-session journal
# (compacted AI responses) into the system prompt.
JOURNAL=0
# OPENAI_API_KEY=sk-...
# ANTHROPIC_API_KEY=sk-ant-...
EOF
  fi
fi

if [ ! -f "$INST_DIR/00-default.md" ]; then
  cat > "$INST_DIR/00-default.md" <<'EOF'
You are a helpful assistant running in a sandboxed Linux terminal in a
browser tab (LinuxOnTab). Keep answers concise and copy-paste friendly.
Use plain ASCII output unless markdown is explicitly requested.
EOF
fi

if [ ! -f "$PROMPT_DIR/tool-system.txt" ]; then
  cat > "$PROMPT_DIR/tool-system.txt" <<'EOF'
# Shell tool

You can execute shell commands in the user's current shell by emitting one
or more blocks of the form:

<shell>
command here
</shell>

Rules:
- Only emit a <shell> block when running a command is genuinely needed to
  answer the user. For purely informational answers, do not emit one.
- The block contents are passed verbatim to `sh -c`. Combined stdout+stderr
  (truncated) and the exit code are returned in the next turn inside
  <shell-result exit=N> ... </shell-result>.
- Multiple <shell> blocks in one reply are run sequentially.
- Do NOT wrap <shell> blocks in markdown code fences. Emit the raw tags.
- After you receive shell-result(s), continue the conversation: either run
  more commands, or summarize the outcome for the user. Stop emitting
  <shell> blocks once you have what you need.
- Prefer non-interactive, idempotent commands. Avoid destructive operations
  unless the user explicitly asked for them.
EOF
fi

if [ ! -f "$PROMPT_DIR/memory-user-compact.txt" ]; then
  cat > "$PROMPT_DIR/memory-user-compact.txt" <<'EOF'
You are a memory compactor. The user gave the following messages to an assistant in past sessions. Most are one-off requests and should be discarded. Extract ONLY content that is overarching and worth remembering forever: explicit rules, persistent preferences, durable facts about the user or their environment, naming conventions, project context that future turns will need.

Output a markdown bulleted list under a heading "## Session rules and persistent info". Use short imperative bullets. Quote exact phrasing for hard rules. If nothing in the input qualifies, output exactly the single word: NONE
EOF
fi

if [ ! -f "$PROMPT_DIR/memory-assistant-compact.txt" ]; then
  cat > "$PROMPT_DIR/memory-assistant-compact.txt" <<'EOF'
You are a memory compactor. Summarize the following past assistant replies into a brief journal entry capturing: key facts produced, decisions made, files/commands of lasting relevance, and notable outcomes. Skip routine acknowledgments and conversational filler. Output markdown under a heading "## Journal entry (<UTC timestamp>)". Be terse - 5 to 15 bullets. If nothing is worth journaling, output exactly NONE.
EOF
fi

if [ ! -f "$PROMPT_DIR/mentor-review.txt" ]; then
  cat > "$PROMPT_DIR/mentor-review.txt" <<'EOF'
You are the mentor of another assistant. Evaluate the assistant's response against the original user request.

Output plain text with exactly these sections:
1) Verdict: PASS or REVISE
2) Strengths: short bullets
3) Issues: short bullets (be specific, especially missing requirements)
4) Actionable feedback for assistant: numbered list of concrete fixes

Keep feedback concise and implementation-focused.
EOF
fi

if [ ! -f "$PROMPT_DIR/mentor-revision.txt" ]; then
  cat > "$PROMPT_DIR/mentor-revision.txt" <<'EOF'
Revise your previous answer based on mentor feedback.

Requirements:
- Fully address the original user request.
- Apply every actionable mentor item unless it conflicts with the user's request.
- Keep the response concise, concrete, and directly usable.
- If the mentor is wrong about something, briefly explain and proceed correctly.
EOF
fi

# shellcheck disable=SC1090
. "$CFG_FILE"
: "${PROVIDER:=openai}"
: "${MODEL_OPENAI:=gpt-5.5}"
: "${MODEL_ANTHROPIC:=claude-sonnet-4-5}"
: "${OPENAI_BASE_URL:=https://api.openai.com/v1}"
: "${ANTHROPIC_BASE_URL:=https://api.anthropic.com/v1}"
: "${OPENAI_API_KEY:=}"
: "${ANTHROPIC_API_KEY:=}"
: "${TOOLS:=1}"
: "${TOOL_MAX_ITERS:=50}"
: "${TOOL_OUTPUT_LIMIT:=32768}"
: "${CLAW_YOLO:=1}"
: "${MENTOR:=0}"
: "${MENTOR_TOOLS:=1}"
: "${USER_WINDOW:=2000}"
: "${ASSIST_WINDOW:=2000}"
: "${JOURNAL:=0}"
: "${MARKDOWN:=off}"

SESSION="default"
EXTRA_INST=""
NO_MEMORY=0
NO_INST=0
RESET=0
ONE_SHOT_MSG=""

usage() { sed -n '2,50p' "$0" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
  case "$1" in
    -s) SESSION="$2"; shift 2 ;;
    -i) EXTRA_INST="$EXTRA_INST $2"; shift 2 ;;
    -m) MODEL_OPENAI="$2"; MODEL_ANTHROPIC="$2"; shift 2 ;;
    -p) PROVIDER="$2"; shift 2 ;;
    --no-memory) NO_MEMORY=1; shift ;;
    --no-instructions) NO_INST=1; shift ;;
    --no-tools) TOOLS=0; shift ;;
    --yolo) CLAW_YOLO=1; shift ;;
    --confirm|--no-yolo) CLAW_YOLO=0; shift ;;
    --mentor) MENTOR=1; shift ;;
    --no-mentor) MENTOR=0; shift ;;
    --reset) RESET=1; shift ;;
    --journal) JOURNAL=1; shift ;;
    --no-journal) JOURNAL=0; shift ;;
    --md) MARKDOWN=on; shift ;;
    --no-md) MARKDOWN=off; shift ;;
    --user-window) USER_WINDOW="$2"; shift 2 ;;
    --assist-window) ASSIST_WINDOW="$2"; shift 2 ;;
    --where) printf 'CFG_DIR=%s\nDATA_DIR=%s\n' "$CFG_DIR" "$DATA_DIR"; exit 0 ;;
    -h|--help) usage; exit 0 ;;
    --) shift; ONE_SHOT_MSG="$*"; break ;;
    -*) echo "unknown flag: $1" >&2; exit 2 ;;
    *) ONE_SHOT_MSG="$*"; break ;;
  esac
done

JOUR_DIR="$DATA_DIR/journals"
mkdir -p "$JOUR_DIR"

USER_LOG="$SESS_DIR/$SESSION.user.jsonl"
ASSIST_LOG="$SESS_DIR/$SESSION.assistant.jsonl"
RULES_FILE="$INST_DIR/90-$SESSION-rules.md"
JOURNAL_FILE="$JOUR_DIR/$SESSION.journal.md"
LEGACY_FILE="$SESS_DIR/$SESSION.json"

# Migrate legacy single-JSON session into the new split jsonl format.
if [ -f "$LEGACY_FILE" ] && [ ! -f "$USER_LOG" ] && [ ! -f "$ASSIST_LOG" ]; then
  ts0=$(date +%s)
  jq -r --argjson ts0 "$ts0" '
    to_entries[] |
    select(.value.role=="user") |
    {ts:($ts0+.key), content:.value.content} | tojson
  ' "$LEGACY_FILE" > "$USER_LOG" 2>/dev/null || : > "$USER_LOG"
  jq -r --argjson ts0 "$ts0" '
    to_entries[] |
    select(.value.role=="assistant") |
    {ts:($ts0+.key), content:.value.content} | tojson
  ' "$LEGACY_FILE" > "$ASSIST_LOG" 2>/dev/null || : > "$ASSIST_LOG"
  mv "$LEGACY_FILE" "$LEGACY_FILE.migrated" 2>/dev/null || true
fi

if [ "$RESET" = 1 ]; then
  rm -f "$USER_LOG" "$ASSIST_LOG"
fi
[ -f "$USER_LOG" ]   || : > "$USER_LOG"
[ -f "$ASSIST_LOG" ] || : > "$ASSIST_LOG"

active_model() {
  if [ "$PROVIDER" = anthropic ]; then echo "$MODEL_ANTHROPIC"; else echo "$MODEL_OPENAI"; fi
}

tool_system_prompt() {
  [ "$TOOLS" = 1 ] || return 0
  [ -f "$PROMPT_DIR/tool-system.txt" ] && cat "$PROMPT_DIR/tool-system.txt"
  cat <<'EOF'

Additional reliability rules:
- Prefer POSIX-sh compatible commands unless the user explicitly asks for bash.
- For multi-line file writes, use quoted heredocs (cat <<'EOF') so strings are not expanded.
- After each file edit, verify immediately with a read/check command and only then continue.
- If an edit command fails, inspect stderr and retry with a safer method rather than guessing.
- When replacing full files, write to a temp file and move it into place atomically.
EOF
}

# ----------------------------------------------------------------------
# Markdown rendering for assistant replies
# ----------------------------------------------------------------------
has_markdown() {
  # Quick heuristic: look for any common markdown construct.
  grep -qE '^(#{1,6} |[-*+] |[0-9]+\. |```|>)|`[^`]+`|\*\*[^*]+\*\*|\[[^]]+\]\([^)]+\)' "$1"
}

render_markdown() {
  if command -v glow >/dev/null 2>&1; then
    glow -s dark "$1" 2>/dev/null && return 0
  fi
  if command -v mdcat >/dev/null 2>&1; then
    mdcat "$1" 2>/dev/null && return 0
  fi
  if command -v bat >/dev/null 2>&1; then
    bat -pp -l md --color=always "$1" 2>/dev/null && return 0
  fi
  md_awk_render "$1"
}

# Tiny built-in markdown -> ANSI renderer. Handles:
# headings, fenced code, bullets, **bold**, *italic*, `inline code`,
# [text](url) → text (url, dim).
md_awk_render() {
  awk '
    BEGIN {
      B="\033[1m"; D="\033[2m"; R="\033[0m"
      I="\033[3m"; UND="\033[4m"
      C1="\033[36m"; C2="\033[33m"; H="\033[1;35m"
      in_code=0
    }
    function inline(s,    out, pre, mid, post, sm, inner, ti, text, url) {
      out = s
      while (match(out, /`[^`]+`/)) {
        pre = substr(out, 1, RSTART-1)
        mid = substr(out, RSTART+1, RLENGTH-2)
        post = substr(out, RSTART+RLENGTH)
        out = pre C1 mid R post
      }
      while (match(out, /\*\*[^*]+\*\*/)) {
        pre = substr(out, 1, RSTART-1)
        mid = substr(out, RSTART+2, RLENGTH-4)
        post = substr(out, RSTART+RLENGTH)
        out = pre B mid R post
      }
      while (match(out, /(^|[^*])\*[^*]+\*/)) {
        sm = substr(out, RSTART, RLENGTH)
        if (substr(sm,1,1) == "*") {
          pre = substr(out, 1, RSTART-1)
          inner = substr(sm, 2, length(sm)-2)
          post = substr(out, RSTART+RLENGTH)
        } else {
          pre = substr(out, 1, RSTART-1) substr(sm, 1, 1)
          inner = substr(sm, 3, length(sm)-3)
          post = substr(out, RSTART+RLENGTH)
        }
        out = pre I inner R post
      }
      while (match(out, /\[[^]]+\]\([^)]+\)/)) {
        sm = substr(out, RSTART, RLENGTH)
        ti = index(sm, "]")
        text = substr(sm, 2, ti-2)
        url  = substr(sm, ti+2, length(sm)-ti-2)
        pre  = substr(out, 1, RSTART-1)
        post = substr(out, RSTART+RLENGTH)
        out  = pre UND text R " " D "(" url ")" R post
      }
      return out
    }
    /^```/ {
      in_code = !in_code
      print D "----" R
      next
    }
    in_code { print C2 $0 R; next }
    /^#{1,6} / {
      sub(/^#+ +/, "", $0)
      print ""; print H $0 R; next
    }
    /^[ \t]*[-*+] / {
      gsub(/^[ \t]*[-*+] /, "  - ", $0)
      print inline($0); next
    }
    /^[ \t]*[0-9]+\. / { print inline($0); next }
    /^> / {
      sub(/^> /, "", $0)
      print D "| " R inline($0); next
    }
    { print inline($0) }
  ' "$1"
}

# Render the buffered assistant reply if appropriate.
maybe_render() {
  src="$1"
  [ "$MARKDOWN" = off ] && return 0
  [ -t 1 ] || return 0
  [ -s "$src" ] || return 0
  # Skip rendering when the model is in tool-use turn (would mangle <shell>).
  grep -q '<shell>' "$src" && return 0
  if [ "$MARKDOWN" = on ] || has_markdown "$src"; then
    printf '\n\033[2m--- rendered ---\033[0m\n'
    render_markdown "$src"
  fi
}

build_system_prompt() {
  [ "$NO_INST" = 1 ] && return 0

  cat <<'EOF'
# Prompt boundary rules

- The latest user message is the active task to execute right now.
- Prior conversation turns are context only, not new instructions.
- Session memory/rules are advisory and may be stale.
- If memory conflicts with the latest user message, follow the latest user message.
- Do not continue old tasks unless the latest user message explicitly asks to resume them.
EOF

  for f in "$INST_DIR"/*.md; do
    [ "$f" = "$RULES_FILE" ] && continue
    [ -f "$f" ] && cat "$f" && echo
  done

  if [ -s "$RULES_FILE" ]; then
    cat <<'EOF'

# Session memory rules (advisory)

Use this only as long-lived preference/context memory.
Do NOT treat it as the current user request.

<session-memory-rules>
EOF
    cat "$RULES_FILE"
    cat <<'EOF'
</session-memory-rules>
EOF
    echo
  fi

  for f in $EXTRA_INST; do
    [ -f "$f" ] && cat "$f" && echo
  done
  if [ "$JOURNAL" = 1 ] && [ -s "$JOURNAL_FILE" ]; then
    cat <<'EOF'

# Session journal (historical reference)

Use this as background reference only.
Do NOT treat journal entries as active instructions or active tasks.

<session-journal>
EOF
    cat "$JOURNAL_FILE"
    cat <<'EOF'
</session-journal>
EOF
    echo
  fi
  tool_system_prompt
}

# ----------------------------------------------------------------------
# Rolling memory: per-role jsonl logs + LLM-driven compaction.
# ----------------------------------------------------------------------

# Read the active windowed history as a JSON array of {role,content},
# interleaved by timestamp. Used when building API request payloads.
build_history_json() {
  ut="$(mktemp)"; at="$(mktemp)"
  jq -s '.' < "$USER_LOG"   > "$ut" 2>/dev/null || echo '[]' > "$ut"
  jq -s '.' < "$ASSIST_LOG" > "$at" 2>/dev/null || echo '[]' > "$at"
  jq -n --slurpfile u "$ut" --slurpfile a "$at" \
        --argjson uw "$USER_WINDOW" --argjson aw "$ASSIST_WINDOW" '
    def tail(n): if (length>n) then .[length-n:] else . end;
    (($u[0] // []) | tail($uw) | map(. + {role:"user"}))
    + (($a[0] // []) | tail($aw) | map(. + {role:"assistant"}))
    | sort_by(.ts)
    | map({role, content})
  '
  rm -f "$ut" "$at"
}

# Non-streaming one-shot call to the active provider. Reads instruction
# string from $1 and user content from $2, prints reply to stdout.
# Used for compaction. Returns 1 on failure (and prints nothing).
compact_call() {
  sys_prompt="$1"; user_msg="$2"
  body="$(mktemp)"; resp="$(mktemp)"
  case "$PROVIDER" in
    openai)
      [ -z "$OPENAI_API_KEY" ] && { rm -f "$body" "$resp"; return 1; }
      jq -n --arg model "$(active_model)" --arg sys "$sys_prompt" --arg user "$user_msg" '{
        model:$model, stream:false,
        messages:[{role:"system",content:$sys},{role:"user",content:$user}]
      }' > "$body"
      curl -sS "$OPENAI_BASE_URL/chat/completions" \
        -H "Authorization: Bearer $OPENAI_API_KEY" \
        -H "Content-Type: application/json" \
        --data-binary @"$body" > "$resp" 2>/dev/null
      jq -r '.choices[0].message.content // empty' "$resp" 2>/dev/null
      ;;
    anthropic)
      [ -z "$ANTHROPIC_API_KEY" ] && { rm -f "$body" "$resp"; return 1; }
      jq -n --arg model "$(active_model)" --arg sys "$sys_prompt" --arg user "$user_msg" '{
        model:$model, stream:false, max_tokens:2048,
        system:$sys, messages:[{role:"user",content:$user}]
      }' > "$body"
      curl -sS "$ANTHROPIC_BASE_URL/messages" \
        -H "x-api-key: $ANTHROPIC_API_KEY" \
        -H "anthropic-version: 2023-06-01" \
        -H "Content-Type: application/json" \
        --data-binary @"$body" > "$resp" 2>/dev/null
      jq -r '[.content[]? | select(.type=="text") | .text] | join("")' "$resp" 2>/dev/null
      ;;
  esac
  rc=$?
  rm -f "$body" "$resp"
  return $rc
}

USER_COMPACT_PROMPT="$(cat "$PROMPT_DIR/memory-user-compact.txt" 2>/dev/null)"
ASSIST_COMPACT_PROMPT="$(cat "$PROMPT_DIR/memory-assistant-compact.txt" 2>/dev/null)"
MENTOR_REVIEW_PROMPT="$(cat "$PROMPT_DIR/mentor-review.txt" 2>/dev/null)"
MENTOR_REVISION_PROMPT="$(cat "$PROMPT_DIR/mentor-revision.txt" 2>/dev/null)"

# Compact overflow lines from $1 (jsonl) using $2 as the system prompt and
# append result to $3 (target file). Trim $1 to last $4 lines on success.
compact_overflow() {
  log_file="$1"; sys_prompt="$2"; out_file="$3"; window="$4"
  total=$(wc -l < "$log_file" 2>/dev/null | tr -d ' ')
  total=${total:-0}
  [ "$total" -le "$window" ] && return 0
  overflow=$((total - window))
  batch="$(head -n "$overflow" "$log_file" \
    | jq -r '.content' \
    | awk 'BEGIN{n=0} {n++; print "---\n[entry "n"]\n"$0}')"
  printf '\n\033[2m[claw] compacting %d %s entries...\033[0m\n' \
    "$overflow" "$(basename "$log_file" .jsonl)" >&2
  result="$(compact_call "$sys_prompt" "$batch")"
  case "$result" in
    ""|NONE|None|none)
      ;;
    *)
      mkdir -p "$(dirname "$out_file")"
      {
        printf '\n<!-- compacted %s UTC, %d entries -->\n' \
          "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$overflow"
        printf '%s\n' "$result"
      } >> "$out_file"
      ;;
  esac
  tmp="$(mktemp)"
  tail -n "$window" "$log_file" > "$tmp" && mv "$tmp" "$log_file"
}

append_user() {
  [ "$NO_MEMORY" = 1 ] && return 0
  jq -nc --arg c "$1" --argjson ts "$(date +%s)" '{ts:$ts, content:$c}' \
    >> "$USER_LOG"
  compact_overflow "$USER_LOG" "$USER_COMPACT_PROMPT" "$RULES_FILE" "$USER_WINDOW"
}

append_assistant() {
  [ "$NO_MEMORY" = 1 ] && return 0
  jq -nc --arg c "$1" --argjson ts "$(date +%s)" '{ts:$ts, content:$c}' \
    >> "$ASSIST_LOG"
  compact_overflow "$ASSIST_LOG" "$ASSIST_COMPACT_PROMPT" "$JOURNAL_FILE" "$ASSIST_WINDOW"
}

# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
# Run curl, strip CR from SSE, tee raw to debug log if CLAW_DEBUG=1.
# Reads from stdin (the request body file), writes SSE lines to stdout.
stream_curl() {
  url="$1"; shift
  body="$1"; shift
  if [ "${CLAW_DEBUG:-0}" = 1 ]; then
    raw="$(mktemp)"
    curl -sS -N "$url" "$@" --data-binary @"$body" | tee "$raw" | tr -d '\r'
    echo "[claw-debug] raw response saved to $raw" >&2
  else
    curl -sS -N "$url" "$@" --data-binary @"$body" | tr -d '\r'
  fi
}

# ----------------------------------------------------------------------
# Provider: OpenAI (Chat Completions, streaming SSE)
# ----------------------------------------------------------------------
send_openai() {
  user_msg="$1"
  active_user_msg="$(
    {
      printf '## Active user request (highest priority)\n'
      printf '%s\n' "$user_msg"
      printf '\n## End active user request\n'
    }
  )"
  if [ -z "$OPENAI_API_KEY" ]; then
    echo "clawlite: OPENAI_API_KEY not set (edit $CFG_FILE or export it)" >&2
    return 1
  fi
  sys="$(build_system_prompt)"
  hist_file="$(mktemp)"
  build_history_json > "$hist_file"
  body="$(mktemp)"
  jq -n \
    --arg model "$(active_model)" \
    --arg sys "$sys" \
    --arg user "$active_user_msg" \
    --slurpfile hist "$hist_file" '
    {
      model: $model,
      stream: true,
      messages:
        ((if ($sys|length) > 0 then [{role:"system", content:$sys}] else [] end)
         + $hist[0]
         + [{role:"user", content:$user}])
    }' > "$body"
  rm -f "$hist_file"
  reply_file="$(mktemp)"
  : > "$reply_file"
  saw_data=0
  raw_acc="$(mktemp)"
  stream_curl "$OPENAI_BASE_URL/chat/completions" "$body" \
    -H "Authorization: Bearer $OPENAI_API_KEY" \
    -H "Content-Type: application/json" \
    | tee "$raw_acc" | while IFS= read -r line; do
      case "$line" in
        "data: [DONE]") break ;;
        "data: "*)
          chunk="${line#data: }"
          delta="$(printf '%s' "$chunk" | jq -r '.choices[0].delta.content // empty' 2>/dev/null)"
          if [ -n "$delta" ]; then
            printf '%s' "$delta"
            printf '%s' "$delta" >> "$reply_file"
            echo 1 > "${reply_file}.saw"
          fi
          err="$(printf '%s' "$chunk" | jq -r '.error.message // empty' 2>/dev/null)"
          [ -n "$err" ] && printf '\n[openai error: %s]\n' "$err" >&2
          ;;
      esac
    done
  echo
  # If no streamed delta arrived, the response was probably a plain JSON
  # error (HTTP 400/401/etc). Show it.
  [ -f "${reply_file}.saw" ] && saw_data=1
  if [ "$saw_data" = 0 ]; then
    msg="$(jq -r '.error.message // .error // empty' "$raw_acc" 2>/dev/null)"
    if [ -n "$msg" ]; then
      printf '[openai error] %s\n' "$msg" >&2
    else
      echo "[clawlite] no response received. raw output:" >&2
      sed 's/^/  /' "$raw_acc" >&2
    fi
  fi
  maybe_render "$reply_file"
  reply="$(cat "$reply_file")"
  rm -f "$reply_file" "${reply_file}.saw" "$body" "$raw_acc"
  if [ -n "$reply" ]; then
    append_user      "$user_msg"
    append_assistant "$reply"
  fi
  if [ -n "${REPLY_OUT:-}" ]; then
    printf '%s' "$reply" > "$REPLY_OUT"
  fi
}

# ----------------------------------------------------------------------
# Provider: Anthropic (Messages API, streaming SSE)
# ----------------------------------------------------------------------
send_anthropic() {
  user_msg="$1"
  active_user_msg="$(
    {
      printf '## Active user request (highest priority)\n'
      printf '%s\n' "$user_msg"
      printf '\n## End active user request\n'
    }
  )"
  if [ -z "$ANTHROPIC_API_KEY" ]; then
    echo "clawlite: ANTHROPIC_API_KEY not set (edit $CFG_FILE or export it)" >&2
    return 1
  fi
  sys="$(build_system_prompt)"
  hist_file="$(mktemp)"
  build_history_json > "$hist_file"
  body="$(mktemp)"
  jq -n \
    --arg model "$(active_model)" \
    --arg sys "$sys" \
    --arg user "$active_user_msg" \
    --slurpfile hist "$hist_file" '
    {
      model: $model,
      stream: true,
      max_tokens: 4096,
      system: $sys,
      messages: ($hist[0] + [{role:"user", content:$user}])
    }' > "$body"
  rm -f "$hist_file"
  reply_file="$(mktemp)"
  : > "$reply_file"
  raw_acc="$(mktemp)"
  stream_curl "$ANTHROPIC_BASE_URL/messages" "$body" \
    -H "x-api-key: $ANTHROPIC_API_KEY" \
    -H "anthropic-version: 2023-06-01" \
    -H "Content-Type: application/json" \
    | tee "$raw_acc" | while IFS= read -r line; do
      case "$line" in
        "data: "*)
          chunk="${line#data: }"
          delta="$(printf '%s' "$chunk" | jq -r 'select(.type=="content_block_delta") | .delta.text // empty' 2>/dev/null)"
          if [ -n "$delta" ]; then
            printf '%s' "$delta"
            printf '%s' "$delta" >> "$reply_file"
            echo 1 > "${reply_file}.saw"
          fi
          err="$(printf '%s' "$chunk" | jq -r 'select(.type=="error") | .error.message // empty' 2>/dev/null)"
          [ -n "$err" ] && printf '\n[anthropic error: %s]\n' "$err" >&2
          ;;
      esac
    done
  echo
  if [ ! -f "${reply_file}.saw" ]; then
    msg="$(jq -r '.error.message // .error // empty' "$raw_acc" 2>/dev/null)"
    if [ -n "$msg" ]; then
      printf '[anthropic error] %s\n' "$msg" >&2
    else
      echo "[clawlite] no response received. raw output:" >&2
      sed 's/^/  /' "$raw_acc" >&2
    fi
  fi
  maybe_render "$reply_file"
  reply="$(cat "$reply_file")"
  rm -f "$reply_file" "${reply_file}.saw" "$body" "$raw_acc"
  if [ -n "$reply" ]; then
    append_user      "$user_msg"
    append_assistant "$reply"
  fi
  if [ -n "${REPLY_OUT:-}" ]; then
    printf '%s' "$reply" > "$REPLY_OUT"
  fi
}

send_provider() {
  case "$PROVIDER" in
    openai)    send_openai    "$1" ;;
    anthropic) send_anthropic "$1" ;;
    *) echo "clawlite: unknown provider '$PROVIDER'" >&2; return 1 ;;
  esac
}

# Extract <shell>...</shell> blocks from $1 into numbered files in dir $2.
# Prints the count.
extract_shell_blocks() {
  awk -v dir="$2" '
    BEGIN { RS="<shell>"; n=0 }
    NR>1 {
      p = index($0, "</shell>")
      if (p>0) {
        n++
        f = sprintf("%s/cmd-%03d", dir, n)
        printf "%s", substr($0, 1, p-1) > f
        close(f)
      }
    }
    END { print n }
  ' "$1"
}

# Strip leading/trailing whitespace from a file's contents.
trim_cmd() {
  awk 'BEGIN{ORS=""} {buf=buf $0 "\n"} END{
    sub(/^[ \t\r\n]+/,"",buf); sub(/[ \t\r\n]+$/,"",buf); print buf
  }' "$1"
}

run_tool_loop() {
  rf="$1"
  iter=0
  while [ "$iter" -lt "$TOOL_MAX_ITERS" ]; do
    workdir="$(mktemp -d)"
    n=$(extract_shell_blocks "$rf" "$workdir")
    if [ "${n:-0}" -eq 0 ]; then
      rm -rf "$workdir"
      return 0
    fi
    iter=$((iter+1))
    results_file="$(mktemp)"
    : > "$results_file"
    i=1
    while [ "$i" -le "$n" ]; do
      cmd_path="$workdir/cmd-$(printf '%03d' "$i")"
      cmd="$(trim_cmd "$cmd_path")"
      printf '\n\033[36m[claw] tool call %d/%d:\033[0m\n%s\n' "$i" "$n" "$cmd" >&2
      run_it=1
      if [ "$CLAW_YOLO" != 1 ]; then
        if [ -r /dev/tty ]; then
          printf '\033[33m[claw] run? [y/N/a=yes-all/q=stop] \033[0m' >&2
          ans=""
          read -r ans </dev/tty || ans=""
        else
          ans="n"
        fi
        case "$ans" in
          a|A) CLAW_YOLO=1; run_it=1 ;;
          y|Y) run_it=1 ;;
          q|Q) run_it=0; SKIP_REST=1 ;;
          *)   run_it=0 ;;
        esac
      fi
      out_file="$(mktemp)"
      if [ "$run_it" = 1 ]; then
        sh -c "$cmd" >"$out_file" 2>&1
        ec=$?
      else
        echo "[skipped by user]" > "$out_file"
        ec=-1
      fi
      bytes=$(wc -c < "$out_file" | tr -d ' ')
      if [ "$bytes" -gt "$TOOL_OUTPUT_LIMIT" ]; then
        out="$(head -c "$TOOL_OUTPUT_LIMIT" "$out_file")
[...truncated, $bytes bytes total]"
      else
        out="$(cat "$out_file")"
      fi
      printf '\033[2m%s\033[0m\n[exit %s]\n' "$out" "$ec" >&2
      {
        printf '<shell-result exit=%s>\n' "$ec"
        printf '%s\n' "$out"
        printf '</shell-result>\n'
      } >> "$results_file"
      rm -f "$out_file"
      i=$((i+1))
      if [ "${SKIP_REST:-0}" = 1 ]; then break; fi
    done
    rm -rf "$workdir"
    if [ "${SKIP_REST:-0}" = 1 ]; then
      rm -f "$results_file"; SKIP_REST=0
      return 0
    fi
    follow_up="$(cat "$results_file")"
    rm -f "$results_file"
    REPLY_OUT="$rf"
    : > "$rf"
    send_provider "$follow_up" || return 1
    REPLY_OUT=""
  done
  echo "\n[claw] tool loop hit max iterations ($TOOL_MAX_ITERS)" >&2
  return 0
}

send_single() {
  user_msg="$1"
  capture_file="${2:-}"
  if [ "$TOOLS" = 1 ]; then
    out_path="$(mktemp)"
    REPLY_OUT="$out_path"
    send_provider "$user_msg" || { rm -f "$out_path"; REPLY_OUT=""; return 1; }
    REPLY_OUT=""
    run_tool_loop "$out_path"
    rc=$?
    if [ -n "$capture_file" ]; then
      cat "$out_path" > "$capture_file"
    fi
    rm -f "$out_path"
    return $rc
  else
    if [ -n "$capture_file" ]; then
      REPLY_OUT="$capture_file"
      send_provider "$user_msg"
      rc=$?
      REPLY_OUT=""
      return $rc
    fi
    send_provider "$user_msg"
  fi
}

mentor_review_prompt() {
  initial_user="$1"
  first_reply="$2"
  [ -n "$MENTOR_REVIEW_PROMPT" ] || return 1
  {
    printf '%s\n\n' "$MENTOR_REVIEW_PROMPT"
    printf 'Review instructions:\n'
    printf '%s\n' '- You are the mentor pass. Validate whether the first assistant actually completed the request.'
    printf '%s\n' '- If tools are available, inspect workspace files/results before giving feedback.'
    printf '%s\n' '- Prefer read-only commands for review (ls/find/cat/sed/git status).'
    printf '%s\n\n' '- Focus on missing requirements, incorrect edits, and verification gaps.'
    printf 'Original user request:\n'
    printf '%s\n\n' "$initial_user"
    printf 'First assistant response:\n'
    printf '%s\n' "$first_reply"
  }
}

mentor_revise_prompt() {
  initial_user="$1"
  first_reply="$2"
  feedback="$3"
  {
    printf '%s\n\n' "$MENTOR_REVISION_PROMPT"
    printf 'Original user request:\n'
    printf '%s\n\n' "$initial_user"
    printf 'Your previous response:\n'
    printf '%s\n\n' "$first_reply"
    printf 'Mentor feedback:\n'
    printf '%s\n' "$feedback"
  }
}

send() {
  msg="$1"
  if [ "$MENTOR" != 1 ]; then
    send_single "$msg"
    return $?
  fi

  # Mentor mode runs two assistant passes and stores only the final answer.
  saved_no_memory="$NO_MEMORY"
  saved_tools="$TOOLS"
  NO_MEMORY=1

  first_out="$(mktemp)"
  mentor_out="$(mktemp)"
  final_out="$(mktemp)"
  send_single "$msg" "$first_out" || {
    NO_MEMORY="$saved_no_memory"
    TOOLS="$saved_tools"
    rm -f "$first_out" "$mentor_out" "$final_out"
    return 1
  }
  first_reply="$(cat "$first_out")"

  if [ "$MENTOR_TOOLS" = 1 ]; then
    TOOLS=1
  fi
  review_msg="$(mentor_review_prompt "$msg" "$first_reply")"
  if send_single "$review_msg" "$mentor_out"; then
    feedback="$(cat "$mentor_out")"
  else
    feedback=""
  fi
  TOOLS="$saved_tools"

  if [ -z "$feedback" ]; then
    feedback="1) Verdict: REVISE
2) Strengths:
- first pass executed
3) Issues:
- mentor review failed to generate feedback
4) Actionable feedback for assistant:
1. Re-check the original user request line by line and ensure all requested file edits were completed and verified."
    echo "[mentor] review failed; using fallback feedback and continuing second pass" >&2
  fi
  printf '\n\033[35m[mentor]\033[0m\n%s\n' "$feedback"

  rev_msg="$(mentor_revise_prompt "$msg" "$first_reply" "$feedback")"
  send_single "$rev_msg" "$final_out" || {
    NO_MEMORY="$saved_no_memory"
    TOOLS="$saved_tools"
    rm -f "$first_out" "$mentor_out" "$final_out"
    return 1
  }
  final_reply="$(cat "$final_out")"

  NO_MEMORY="$saved_no_memory"
  TOOLS="$saved_tools"
  if [ "$saved_no_memory" = 0 ] && [ -n "$final_reply" ]; then
    append_user "$msg"
    append_assistant "$final_reply"
  fi

  rm -f "$first_out" "$mentor_out" "$final_out"
}

# ----------------------------------------------------------------------
# Slash command dispatch. Returns 2 to signal exit.
# ----------------------------------------------------------------------
handle_slash() {
  cmd="$1"
  case "$cmd" in
    /exit|/quit) return 2 ;;
    /help)       usage ;;
    /reset)
      : > "$USER_LOG"; : > "$ASSIST_LOG"
      echo "(session reset: $SESSION  — instruction rules + journal kept)"
      ;;
    /list)
      ls -1 "$SESS_DIR" 2>/dev/null \
        | sed -n 's/\.user\.jsonl$//p' \
        | sort -u \
        | grep -v '^$' || echo "(no sessions)"
      ;;
    "/load "*)
      n="${cmd#/load }"
      SESSION="$n"
      USER_LOG="$SESS_DIR/$n.user.jsonl"
      ASSIST_LOG="$SESS_DIR/$n.assistant.jsonl"
      RULES_FILE="$INST_DIR/90-$n-rules.md"
      JOURNAL_FILE="$JOUR_DIR/$n.journal.md"
      [ -f "$USER_LOG" ]   || : > "$USER_LOG"
      [ -f "$ASSIST_LOG" ] || : > "$ASSIST_LOG"
      echo "(loaded session: $n)"
      ;;
    "/save "*)
      n="${cmd#/save }"
      cp "$USER_LOG"   "$SESS_DIR/$n.user.jsonl"
      cp "$ASSIST_LOG" "$SESS_DIR/$n.assistant.jsonl"
      echo "(saved as: $n)"
      ;;
    "/journal "*)
      n="${cmd#/journal }"
      case "$n" in
        on|1|true)  JOURNAL=1; echo "(journal: on, file=$JOURNAL_FILE)" ;;
        off|0|false) JOURNAL=0; echo "(journal: off)" ;;
        show)
          if [ -s "$JOURNAL_FILE" ]; then cat "$JOURNAL_FILE"
          else echo "(no journal yet)"; fi
          ;;
        *) echo "(usage: /journal on|off|show)" ;;
      esac
      ;;
    /journal) echo "journal: $([ "$JOURNAL" = 1 ] && echo on || echo off)  file: $JOURNAL_FILE" ;;
    "/md "*)
      n="${cmd#/md }"
      case "$n" in
        on|1|true)   MARKDOWN=on; echo "(markdown: on)" ;;
        off|0|false) MARKDOWN=off; echo "(markdown: off)" ;;
        auto)        MARKDOWN=auto; echo "(markdown: auto)" ;;
        *) echo "(usage: /md on|off|auto)" ;;
      esac
      ;;
    /md) echo "markdown: $MARKDOWN" ;;
    "/model "*)
      n="${cmd#/model }"
      if [ "$PROVIDER" = anthropic ]; then MODEL_ANTHROPIC="$n"; else MODEL_OPENAI="$n"; fi
      echo "(model: $n)"
      ;;
    /model)     echo "current model: $(active_model)" ;;
    "/provider "*)
      n="${cmd#/provider }"
      PROVIDER="$n"
      echo "(provider: $n, model: $(active_model))"
      ;;
    /provider)  echo "current provider: $PROVIDER" ;;
    "/tools "*)
      n="${cmd#/tools }"
      case "$n" in
        on|1|true)  TOOLS=1; echo "(tools: on)" ;;
        off|0|false) TOOLS=0; echo "(tools: off)" ;;
        *) echo "(usage: /tools on|off)" ;;
      esac
      ;;
    /tools) echo "tools: $([ "$TOOLS" = 1 ] && echo on || echo off)" ;;
    "/yolo "*)
      n="${cmd#/yolo }"
      case "$n" in
        on|1|true)  CLAW_YOLO=1; echo "(yolo: on — shell tools run without confirm)" ;;
        off|0|false) CLAW_YOLO=0; echo "(yolo: off)" ;;
        *) echo "(usage: /yolo on|off)" ;;
      esac
      ;;
    /yolo) echo "yolo: $([ "$CLAW_YOLO" = 1 ] && echo on || echo off)" ;;
    "/mentor "*)
      n="${cmd#/mentor }"
      case "$n" in
        on|1|true)  MENTOR=1; echo "(mentor: on)" ;;
        off|0|false) MENTOR=0; echo "(mentor: off)" ;;
        *) echo "(usage: /mentor on|off)" ;;
      esac
      ;;
    /mentor) echo "mentor: $([ "$MENTOR" = 1 ] && echo on || echo off)" ;;
    "/inst add "*)
      f="${cmd#/inst add }"
      if [ -f "$f" ]; then EXTRA_INST="$EXTRA_INST $f"; echo "(added: $f)"
      else echo "(no such file: $f)"; fi
      ;;
    "/inst rm "*)
      f="${cmd#/inst rm }"; new=""
      for x in $EXTRA_INST; do [ "$x" != "$f" ] && new="$new $x"; done
      EXTRA_INST="$new"; echo "(removed: $f)"
      ;;
    "/inst list"|"/inst")
      for f in "$INST_DIR"/*.md; do [ -f "$f" ] && echo "$f"; done
      for f in $EXTRA_INST; do echo "$f  (session)"; done
      ;;
    "/inst show")
      build_system_prompt
      ;;
    /paste)
      echo "(multi-line — end with a single line containing only EOF)"
      buf=""
      while IFS= read -r ln; do
        [ "$ln" = "EOF" ] && break
        buf="$buf$ln
"
      done
      [ -n "$buf" ] && send "$buf"
      ;;
    /*) echo "unknown command: $cmd  (try /help)" ;;
    *)  return 1 ;;
  esac
  return 0
}

# ----------------------------------------------------------------------
# One-shot mode (arg or stdin)
# ----------------------------------------------------------------------
if [ -n "$ONE_SHOT_MSG" ]; then
  send "$ONE_SHOT_MSG"
  exit 0
fi
if [ ! -t 0 ]; then
  msg="$(cat)"
  if [ -n "$msg" ]; then send "$msg"; exit 0; fi
fi

# ----------------------------------------------------------------------
# REPL
# ----------------------------------------------------------------------
printf 'clawlite  provider=%s  model=%s  session=%s  tools=%s%s  win=u%s/a%s%s\n' \
  "$PROVIDER" "$(active_model)" "$SESSION" \
  "$([ "$TOOLS" = 1 ] && echo on || echo off)" \
  "$([ "$CLAW_YOLO" = 1 ] && echo ' yolo' || echo '')" \
  "$USER_WINDOW" "$ASSIST_WINDOW" \
  "$([ "$JOURNAL" = 1 ] && echo ' journal' || echo '')$([ "$MENTOR" = 1 ] && echo ' mentor' || echo '')"
printf '(/help for commands, /exit to quit)\n'

while :; do
  printf '\n> '
  IFS= read -r line || { echo; break; }
  [ -z "$line" ] && continue
  case "$line" in
    /*)
      handle_slash "$line"; rc=$?
      [ "$rc" = 2 ] && break
      continue
      ;;
  esac
  send "$line" || true
done
